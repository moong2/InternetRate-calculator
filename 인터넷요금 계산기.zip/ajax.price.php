<?php
include_once('./common.php');
$price_test = mysqli_connect("localhost", "semibizplus1", "white2950!", "semibizplus1");
sql_set_charset('utf8', $price_test);
$sql = " select * from user_price where type1 = '{$type1}' and type2 = '{$type2}' and type3 = '{$type4}' and type4 = '{$type3}' ";
$result = mysqli_query($price_test, $sql);
$row = mysqli_fetch_array($result);

if($row){
	if($type5==1){
		$total_price = $row['p_price1'] + $row['p_price2'];
	}else if($type5==2){
		$total_price = $row['p_price1'] + $row['p_price3'];
	}else{
		$total_price = $row['p_price1'];
	}
}
?>


<!--css-->
<link rel = "stylesheet" href = "css/subcom.css">
<link rel = "stylesheet" href = "css/theme-elements.css">
<link rel = "stylesheet" href = "css/bootstrap.css">
<link rel = "stylesheet" href = "css/layers.css">
<link rel = "stylesheet" href = "css/theme.css">
<link rel = "stylesheet" href = "css/style.css">
<link rel = "stylesheet" href = "css/default.css">
<link rel = "stylesheet" href = "css/skin_default.css">
<style>
	.btn-control{
		width : 100%;
	}
	div {
    	display: block;
	}
	body {
		font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
		font-size: 14px;
		line-height: 1.42857143;
		color: #333;
		background-color: #fff;
	}
	html {
		font-size: 10px;
		-webkit-tap-highlight-color: rgba(0,0,0,0);
	}
	.subcom {
    	font-family: "dotum";
	}
</style>
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<form name="priceform" id="priceform" onsubmit="return s_submit(this)" method="post" enctype="multipart/form-data" action="./online_form.php">
<input type="hidden" name="w" value="<?php echo $w ?>">
<input type="hidden" name="type1" value="<?=$type1?>">
<input type="hidden" name="type2" value="<?=$type2?>">
<input type="hidden" name="type2_type" value="<?=$type2_type?>">
<input type="hidden" name="type3" value="<?=$type3?>">
<input type="hidden" name="type4" value="<?=$type4?>">
<input type="hidden" name="type5" value="<?=$type5?>">
<input type="hidden" name="total_price" value="<?=$total_price?>">
<input type="hidden" name="token" value="">

<div class="conbox">
	<div class="tab_wrp">
		<!--tab1-->
		<div class="sub_top">
			<div class="row">
				<div class="col-xs-5">
					<h1>
						간편요금 계산기									
					</h1>
				</div>
				<div class="col-xs-7 text-right">
					<div class="siteconfig">
						<div class="text-left">
							<span class="home_box home_box1">
								<a href="/">
									<i class="fa fa-home"></i>
								</a>
							</span>
							<span class="home_box home_box2">
								인터넷가이드											
							</span>
							<span class="home_box home_box3">
								간편요금 계산기											
							</span>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="tabs">
			<h2 class="s_tit">
				자유롭게 상품을 선택하고 할인된 요금을 확인해보세요(VAT포함)
			</h2>
			
			<div class="row">
				<div class="col-md-6">
					<ul class="list-unstyled mb-none t_list_txt">
						<li>
							1. 통신사를  선택해 주세요
						</li>
					</ul>
				</div>
				<div class="col-md-6">
					<section class="panel panel-transparent">
						<header class="panel-heading p-none pb-md">
							<p class="panel-subtitle mt-none">통신사 선택</p>
						</header>
						<div class="panel-body">
							<div class="row">
								<div class="col-md-4"><!-- active -->
									<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type1=="1"){echo 'tertiary';}else{echo 'default';}?> btn-control form-call" type="button" type1="1"><?php if($type1=="1"){echo 'LG 유플러스';}else{echo 'LG U+';}?></button>
								</div>
								<div class="col-md-4">
									<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type1=="2"){echo 'secondary';}else{echo 'default';}?> btn-control form-call" type="button" type1="2"><?php if($type1=="2"){echo 'SK 브로드밴드';}else{echo 'SK broadband';}?></button>
								</div>
								<div class="col-md-4">
									<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type1=="3"){echo 'primary active';}else{echo 'default';}?> btn-control form-call" type="button" type1="3"><?php if($type1=="3"){echo 'KT 올레';}else{echo 'KT olleh';}?></button>
								</div>
							</div>
						</div>
					</section>
				</div>
			</div>
			<hr class="tall mt-xs mb-md">

			<div class="row">
				<div class="col-md-6">
					<ul class="list-unstyled mb-none t_list_txt">
						<li>
							2. 인터넷 단독 상품만 원하실경우 선택해주세요
						</li>
					</ul>
				</div>
				<div class="col-md-6">
					<section class="panel panel-transparent">
						<header class="panel-heading p-none pb-md">
							<p class="panel-subtitle mt-none">인터넷 단독</p>
						</header>
						<div class="panel-body">
							<div class="row">
								<?php
									if($type1=="1"){
								?>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type2=="1" && $type2_type=="1"){echo 'tertiary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="1" type2_type="1" type5="<?php echo $type5;?>"><?php if($type2=="1" && $type2_type=="1"){echo $row['type_text2'];}else{echo '100Mbps 속도';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type2=="2" && $type2_type=="1"){echo 'tertiary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="2" type2_type="1" type5="<?php echo $type5;?>"><?php if($type2=="2" && $type2_type=="1"){echo $row['type_text2'];}else{echo '500Mbps 속도';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type2=="3" && $type2_type=="1"){echo 'tertiary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="3" type2_type="1" type5="<?php echo $type5;?>"><?php if($type2=="3" && $type2_type=="1"){echo $row['type_text2'];}else{echo '1Giga 속도';}?></button>
									</div>
								<?php
									}else if($type1=="2"){
								?>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type2=="1" && $type2_type=="1"){echo 'secondary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="1" type2_type="1" type5="<?php echo $type5;?>"><?php if($type2=="1" && $type2_type=="1"){echo $row['type_text2'];}else{echo '100Mbps 속도';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type2=="2" && $type2_type=="1"){echo 'secondary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="2" type2_type="1" type5="<?php echo $type5;?>"><?php if($type2=="2" && $type2_type=="1"){echo $row['type_text2'];}else{echo '500Mbps 속도';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type2=="3" && $type2_type=="1"){echo 'secondary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="3" type2_type="1" type5="<?php echo $type5;?>"><?php if($type2=="3" && $type2_type=="1"){echo $row['type_text2'];}else{echo '1Giga 속도';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type2=="4" && $type2_type=="1"){echo 'secondary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="4" type2_type="1" type5="<?php echo $type5;?>"><?php if($type2=="4" && $type2_type=="1"){echo $row['type_text2'];}else{echo '2.5Giga 속도';}?></button>
									</div>
								<?php
									}else if($type1=="3"){
								?>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type2=="1" && $type2_type=="1"){echo 'primary active';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="1" type2_type="1" type5="<?php echo $type5;?>"><?php if($type2=="1" && $type2_type=="1"){echo $row['type_text2'];}else{echo '100Mbps 속도';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type2=="2" && $type2_type=="1"){echo 'primary active';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="2" type2_type="1" type5="<?php echo $type5;?>"><?php if($type2=="2" && $type2_type=="1"){echo $row['type_text2'];}else{echo '500Mbps 속도';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type2=="3" && $type2_type=="1"){echo 'primary active';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="3" type2_type="1" type5="<?php echo $type5;?>"><?php if($type2=="3" && $type2_type=="1"){echo $row['type_text2'];}else{echo '1Giga 속도';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type2=="4" && $type2_type=="1"){echo 'primary active';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="4" type2_type="1" type5="<?php echo $type5;?>"><?php if($type2=="4" && $type2_type=="1"){echo $row['type_text2'];}else{echo '2.5Giga 속도';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type2=="5" && $type2_type=="1"){echo 'primary active';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="5" type2_type="1" type5="<?php echo $type5;?>"><?php if($type2=="5" && $type2_type=="1"){echo $row['type_text2'];}else{echo '5Giga 속도';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type2=="6" && $type2_type=="1"){echo 'primary active';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="6" type2_type="1" type5="<?php echo $type5;?>"><?php if($type2=="6" && $type2_type=="1"){echo $row['type_text2'];}else{echo '10Giga 속도';}?></button>
									</div>
								<?php
									}else{
								?>	
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-default btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="1" type2_type="1">100Mbps 속도</button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-default btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="2" type2_type="1">500Mbps 속도</button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-default btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="3" type2_type="1">1Giga 속도</button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-default btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="4" type2_type="1">2.5Giga 속도</button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-default btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="5" type2_type="1">5Giga 속도</button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-default btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="6" type2_type="1">10Giga 속도</button>
									</div>
								<?php
									}
								?>
							</div>
						</div>
					</section>
				</div>
			</div>
			<hr class="tall mt-xs mb-md">

			<div class="row">
				<div class="col-md-6">
					<ul class="list-unstyled mb-none t_list_txt">
						<li>
							3. 인터넷 번들 이상 상품만 원하실경우 선택해주세요
						</li>
					</ul>
				</div>
				<div class="col-md-6">
					<section class="panel panel-transparent">
						<header class="panel-heading p-none pb-md">
							<p class="panel-subtitle mt-none">인터넷 번들</p>
						</header>
						<div class="panel-body">
							<div class="row">
								<?php
									if($type1=="1"){
								?>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type2=="1" && $type2_type=="2"){echo 'tertiary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="1" type2_type="2" type3="<?php echo $type3;?>" type4="<?php echo $type4;?>" type5="<?php echo $type5;?>"><?php if($type2=="1" && $type2_type=="2"){echo $row['type_text2'];}else{echo '100Mbps 속도';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type2=="2" && $type2_type=="2"){echo 'tertiary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="2" type2_type="2" type3="<?php echo $type3;?>" type4="<?php echo $type4;?>" type5="<?php echo $type5;?>"><?php if($type2=="2" && $type2_type=="2"){echo $row['type_text2'];}else{echo '500Mbps 속도';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type2=="3" && $type2_type=="2"){echo 'tertiary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="3" type2_type="2" type3="<?php echo $type3;?>" type4="<?php echo $type4;?>" type5="<?php echo $type5;?>"><?php if($type2=="3" && $type2_type=="2"){echo $row['type_text2'];}else{echo '1Giga 속도';}?></button>
									</div>
								<?php
									}else if($type1=="2"){
								?>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type2=="1" && $type2_type=="2"){echo 'secondary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="1" type2_type="2" type3="<?php echo $type3;?>" type4="<?php echo $type4;?>" type5="<?php echo $type5;?>"><?php if($type2=="1" && $type2_type=="2"){echo $row['type_text2'];}else{echo '100Mbps 속도';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type2=="2" && $type2_type=="2"){echo 'secondary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="2" type2_type="2" type3="<?php echo $type3;?>" type4="<?php echo $type4;?>" type5="<?php echo $type5;?>"><?php if($type2=="2" && $type2_type=="2"){echo $row['type_text2'];}else{echo '500Mbps 속도';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type2=="3" && $type2_type=="2"){echo 'secondary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="3" type2_type="2" type3="<?php echo $type3;?>" type4="<?php echo $type4;?>" type5="<?php echo $type5;?>"><?php if($type2=="3" && $type2_type=="2"){echo $row['type_text2'];}else{echo '1Giga 속도';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type2=="4" && $type2_type=="2"){echo 'secondary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="4" type2_type="2" type3="<?php echo $type3;?>" type4="<?php echo $type4;?>" type5="<?php echo $type5;?>"><?php if($type2=="4" && $type2_type=="2"){echo $row['type_text2'];}else{echo '2.5Giga 속도';}?></button>
									</div>
								<?php
									}else if($type1=="3"){
								?>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type2=="1" && $type2_type=="2"){echo 'primary active';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="1" type2_type="2" type3="<?php echo $type3;?>" type4="<?php echo $type4;?>" type5="<?php echo $type5;?>"><?php if($type2=="1" && $type2_type=="2"){echo $row['type_text2'];}else{echo '100Mbps 속도';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type2=="2" && $type2_type=="2"){echo 'primary active';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="2" type2_type="2" type3="<?php echo $type3;?>" type4="<?php echo $type4;?>" type5="<?php echo $type5;?>"><?php if($type2=="2" && $type2_type=="2"){echo $row['type_text2'];}else{echo '500Mbps 속도';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type2=="3" && $type2_type=="2"){echo 'primary active';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="3" type2_type="2" type3="<?php echo $type3;?>" type4="<?php echo $type4;?>" type5="<?php echo $type5;?>"><?php if($type2=="3" && $type2_type=="2"){echo $row['type_text2'];}else{echo '1Giga 속도';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type2=="4" && $type2_type=="2"){echo 'primary active';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="4" type2_type="2" type3="<?php echo $type3;?>" type4="<?php echo $type4;?>" type5="<?php echo $type5;?>"><?php if($type2=="4" && $type2_type=="2"){echo $row['type_text2'];}else{echo '2.5Giga 속도';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type2=="5" && $type2_type=="2"){echo 'primary active';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="5" type2_type="2" type3="<?php echo $type3;?>" type4="<?php echo $type4;?>" type5="<?php echo $type5;?>"><?php if($type2=="5" && $type2_type=="2"){echo $row['type_text2'];}else{echo '5Giga 속도';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type2=="6" && $type2_type=="2"){echo 'primary active';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="6" type2_type="2" type3="<?php echo $type3;?>" type4="<?php echo $type4;?>" type5="<?php echo $type5;?>"><?php if($type2=="6" && $type2_type=="2"){echo $row['type_text2'];}else{echo '10Giga 속도';}?></button>
									</div>
								<?php
									}else{
								?>	
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-default btn-control" type="button">100Mbps 속도</button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-default btn-control" type="button">500Mbps 속도</button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-default btn-control" type="button">1Giga 속도</button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-default btn-control" type="button">2.5Giga 속도</button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-default btn-control" type="button">5Giga 속도</button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-default btn-control" type="button">10Giga 속도</button>
									</div>
								<?php
									}
								?>
							</div>
						</div>
					</section>
					<hr class="tall mt-xs mb-md">
					<section class="panel panel-transparent">
						<header class="panel-heading p-none pb-md">
							<p class="panel-subtitle mt-none">TV</p>
						</header>
						<div class="panel-body">
							<div class="row">
								<?php
									if($type1=="1" && $type2_type=="2"){
								?>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type3=="1" && $type2_type=="2"){echo 'tertiary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="<?php echo $type2;?>" type2_type="<?php echo $type2_type;?>" type3="1" type4="<?php echo $type4;?>" type5="<?php echo $type5;?>"><?php if($type3=="1" && $type2_type=="2"){echo $row['type_text4'];}else{echo '보급 채널';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type3=="2" && $type2_type=="2"){echo 'tertiary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="<?php echo $type2;?>" type2_type="<?php echo $type2_type;?>" type3="2" type4="<?php echo $type4;?>" type5="<?php echo $type5;?>"><?php if($type3=="2" && $type2_type=="2"){echo $row['type_text4'];}else{echo '일반 채널';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type3=="3" && $type2_type=="2"){echo 'tertiary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="<?php echo $type2;?>" type2_type="<?php echo $type2_type;?>" type3="3" type4="<?php echo $type4;?>" type5="<?php echo $type5;?>"><?php if($type3=="3" && $type2_type=="2"){echo $row['type_text4'];}else{echo '고급 채널';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type3=="4" && $type2_type=="2"){echo 'tertiary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="<?php echo $type2;?>" type2_type="<?php echo $type2_type;?>" type3="4" type4="<?php echo $type4;?>" type5="<?php echo $type5;?>"><?php if($type3=="4" && $type2_type=="2"){echo $row['type_text4'];}else{echo '모든 채널';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type3=="5" && $type2_type=="2"){echo 'tertiary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="<?php echo $type2;?>" type2_type="<?php echo $type2_type;?>" type3="5" type4="<?php echo $type4;?>" type5="<?php echo $type5;?>"><?php if($type3=="5" && $type2_type=="2"){echo $row['type_text4'];}else{echo '모든 채널+영화';}?></button>
									</div>
								<?php
									}else if($type1=="2" && $type2_type=="2"){
								?>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type3=="1" && $type2_type=="2"){echo 'secondary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="<?php echo $type2;?>" type2_type="<?php echo $type2_type;?>" type3="1" type4="<?php echo $type4;?>" type5="<?php echo $type5;?>"><?php if($type3=="1" && $type2_type=="2"){echo $row['type_text4'];}else{echo '보급 채널';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type3=="2" && $type2_type=="2"){echo 'secondary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="<?php echo $type2;?>" type2_type="<?php echo $type2_type;?>" type3="2" type4="<?php echo $type4;?>" type5="<?php echo $type5;?>"><?php if($type3=="2" && $type2_type=="2"){echo $row['type_text4'];}else{echo '일반 채널';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type3=="3" && $type2_type=="2"){echo 'secondary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="<?php echo $type2;?>" type2_type="<?php echo $type2_type;?>" type3="3" type4="<?php echo $type4;?>" type5="<?php echo $type5;?>"><?php if($type3=="3" && $type2_type=="2"){echo $row['type_text4'];}else{echo '고급 채널';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type3=="4" && $type2_type=="2"){echo 'secondary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="<?php echo $type2;?>" type2_type="<?php echo $type2_type;?>" type3="4" type4="<?php echo $type4;?>" type5="<?php echo $type5;?>"><?php if($type3=="4" && $type2_type=="2"){echo $row['type_text4'];}else{echo '모든 채널';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type3=="5" && $type2_type=="2"){echo 'secondary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="<?php echo $type2;?>" type2_type="<?php echo $type2_type;?>" type3="5" type4="<?php echo $type4;?>" type5="<?php echo $type5;?>"><?php if($type3=="5" && $type2_type=="2"){echo $row['type_text4'];}else{echo '모든 채널+영화';}?></button>
									</div>
								<?php
									}else if($type1=="3" && $type2_type=="2"){
								?>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type3=="1" && $type2_type=="2"){echo 'primary active';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="<?php echo $type2;?>" type2_type="<?php echo $type2_type;?>" type3="1" type4="<?php echo $type4;?>" type5="<?php echo $type5;?>"><?php if($type3=="1" && $type2_type=="2"){echo $row['type_text4'];}else{echo '보급 채널';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type3=="2" && $type2_type=="2"){echo 'primary active';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="<?php echo $type2;?>" type2_type="<?php echo $type2_type;?>" type3="2" type4="<?php echo $type4;?>" type5="<?php echo $type5;?>"><?php if($type3=="2" && $type2_type=="2"){echo $row['type_text4'];}else{echo '일반 채널';}?></button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type3=="3" && $type2_type=="2"){echo 'primary active';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="<?php echo $type2;?>" type2_type="<?php echo $type2_type;?>" type3="3" type4="<?php echo $type4;?>" type5="<?php echo $type5;?>"><?php if($type3=="3" && $type2_type=="2"){echo $row['type_text4'];}else{echo '고급 채널';}?></button>
									</div>
									<div class="col-md-5">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type3=="4" && $type2_type=="2"){echo 'primary active';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="<?php echo $type2;?>" type2_type="<?php echo $type2_type;?>" type3="4" type4="<?php echo $type4;?>" type5="<?php echo $type5;?>"><?php if($type3=="4" && $type2_type=="2"){echo $row['type_text4'];}else{echo '모든 채널';}?></button>
									</div>
									<div class="col-md-6">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type3=="5" && $type2_type=="2"){echo 'primary active';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="<?php echo $type2;?>" type2_type="<?php echo $type2_type;?>" type3="5" type4="<?php echo $type4;?>" type5="<?php echo $type5;?>"><?php if($type3=="5" && $type2_type=="2"){echo $row['type_text4'];}else{echo '모든 채널+영화';}?></button>
									</div>
								<?php
									}else{
								?>	
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-default btn-control" type="button">보급 채널</button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-default btn-control" type="button">일반 채널</button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-default btn-control" type="button">고급 채널</button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-default btn-control" type="button">모든 채널</button>
									</div>
									<div class="col-md-4">
										<button class="mb-xs mt-xs mr-xs btn btn-default btn-control" type="button">모든 채널+영화</button>
									</div>
								<?php
									}
								?>
							</div>
						</div>
					</section>
					<hr class="tall mt-xs mb-md">
					<section class="panel panel-transparent">
						<header class="panel-heading p-none pb-md">
							<p class="panel-subtitle mt-none">전화</p>
						</header>
						<div class="panel-body">
							<div class="row">
								<?php
									if($type1=="1" && $type2_type=="2"){
								?>
									<div class="col-md-6">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type4=="1" && $type2_type=="2"){echo 'tertiary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="<?php echo $type2;?>" type2_type="<?php echo $type2_type;?>" type3="<?php echo $type3;?>" type4="1" type5="<?php echo $type5;?>"><?php if($type4=="1" && $type2_type=="2"){echo $row['type_text3'];}else{echo '기본요금(일반전화)';}?></button>
									</div>
									<div class="col-md-6">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type4=="2" && $type2_type=="2"){echo 'tertiary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="<?php echo $type2;?>" type2_type="<?php echo $type2_type;?>" type3="<?php echo $type3;?>" type4="2" type5="<?php echo $type5;?>"><?php if($type4=="2" && $type2_type=="2"){echo $row['type_text3'];}else{echo '기본요금(인터넷전화)';}?></button>
									</div>
								<?php
									}else if($type1=="2" && $type2_type=="2"){
								?>
									<div class="col-md-6">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type4=="1" && $type2_type=="2"){echo 'secondary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="<?php echo $type2;?>" type2_type="<?php echo $type2_type;?>" type3="<?php echo $type3;?>" type4="1" type5="<?php echo $type5;?>"><?php if($type4=="1" && $type2_type=="2"){echo $row['type_text3'];}else{echo '기본요금(일반전화)';}?></button>
									</div>
									<div class="col-md-6">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type4=="2" && $type2_type=="2"){echo 'secondary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="<?php echo $type2;?>" type2_type="<?php echo $type2_type;?>" type3="<?php echo $type3;?>" type4="2" type5="<?php echo $type5;?>"><?php if($type4=="2" && $type2_type=="2"){echo $row['type_text3'];}else{echo '기본요금(인터넷전화)';}?></button>
									</div>
								<?php
									}else if($type1=="3" && $type2_type=="2"){
								?>
									<div class="col-md-6">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type4=="1" && $type2_type=="2"){echo 'primary active';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="<?php echo $type2;?>" type2_type="<?php echo $type2_type;?>" type3="<?php echo $type3;?>" type4="1" type5="<?php echo $type5;?>"><?php if($type4=="1" && $type2_type=="2"){echo $row['type_text3'];}else{echo '기본요금(일반전화)';}?></button>
									</div>
									<div class="col-md-6">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type4=="2" && $type2_type=="2"){echo 'primary active';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="<?php echo $type2;?>" type2_type="<?php echo $type2_type;?>" type3="<?php echo $type3;?>" type4="2" type5="<?php echo $type5;?>"><?php if($type4=="2" && $type2_type=="2"){echo $row['type_text3'];}else{echo '기본요금(인터넷전화)';}?></button>
									</div>
								<?php
									}else{
								?>	
									<div class="col-md-6">
										<button class="mb-xs mt-xs mr-xs btn btn-default btn-control" type="button" >기본요금(일반전화)</button>
									</div>
									<div class="col-md-6">
										<button class="mb-xs mt-xs mr-xs btn btn-default btn-control" type="button">기본요금(인터넷전화)</button>
									</div>
								<?php
									}
								?>
							</div>
						</div>
					</section>
				</div>
			</div>
			<hr class="tall mt-xs mb-md">

			<div class="row">
				<div class="col-md-6">
					<ul class="list-unstyled mb-none t_list_txt">
						<li>
							4.해당 이동전화 사용중 이시면 선택해주세요
						</li>
					</ul>
				</div>
				<div class="col-md-6">
					<section class="panel panel-transparent">
						<header class="panel-heading p-none pb-md">
							<p class="panel-subtitle mt-none">이동전화 결합할인</p>
						</header>
						<div class="panel-body">
							<div class="row">
								<?php
									if($type1=="1" && ($type2_type=="1" || $type2_type=="2")){
								?>
									<div class="col-md-6">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type5=="1"){echo 'tertiary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="<?php echo $type2;?>" type2_type="<?php echo $type2_type;?>" type3="<?php echo $type3;?>" type4="<?php echo $type4;?>" type5="1"><?php if($type5=="1"){echo 'LG 핸드폰 1회선 사용';}else{echo '1회선 (요금6만5천원이상)';}?></button>
									</div>
									<div class="col-md-6">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type5=="2"){echo 'tertiary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="<?php echo $type2;?>" type2_type="<?php echo $type2_type;?>" type3="<?php echo $type3;?>" type4="<?php echo $type4;?>" type5="2"><?php if($type5=="2"){echo 'LG 핸드폰 2회선 사용';}else{echo '2회선 (요금6만5천원이상)';}?></button>
									</div>
								<?php
									}else if($type1=="2" && ($type2_type=="1" || $type2_type=="2")){
								?>
									<div class="col-md-6">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type5=="1"){echo 'secondary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="<?php echo $type2;?>" type2_type="<?php echo $type2_type;?>" type3="<?php echo $type3;?>" type4="<?php echo $type4;?>" type5="1"><?php if($type5=="1"){echo 'SK 핸드폰 1회선 사용';}else{echo '1회선 (요금6만5천원이상)';}?></button>
									</div>
									<div class="col-md-6">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type5=="2"){echo 'secondary';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="<?php echo $type2;?>" type2_type="<?php echo $type2_type;?>" type3="<?php echo $type3;?>" type4="<?php echo $type4;?>" type5="2"><?php if($type5=="2"){echo 'SK 핸드폰 2회선 사용';}else{echo '2회선 (요금6만5천원이상)';}?></button>
									</div>
								<?php
									}else if($type1=="3" && ($type2_type=="1" || $type2_type=="2")){
								?>
									<div class="col-md-6">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type5=="1"){echo 'primary active';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="<?php echo $type2;?>" type2_type="<?php echo $type2_type;?>" type3="<?php echo $type3;?>" type4="<?php echo $type4;?>" type5="1"><?php if($type5=="1"){echo 'KT 핸드폰 1회선 사용';}else{echo '1회선 (요금6만5천원이상)';}?></button>
									</div>
									<div class="col-md-6">
										<button class="mb-xs mt-xs mr-xs btn btn-<?php if($type5=="2"){echo 'primary active';}else{echo 'default';}?> btn-control form-call" type="button" type1="<?php echo $type1;?>" type2="<?php echo $type2;?>" type2_type="<?php echo $type2_type;?>" type3="<?php echo $type3;?>" type4="<?php echo $type4;?>" type5="2"><?php if($type5=="2"){echo 'KT 핸드폰 2회선 사용';}else{echo '2회선 (요금6만5천원이상)';}?></button>
									</div>
								<?php
									}else{
								?>	
									<div class="col-md-6">
										<button class="mb-xs mt-xs mr-xs btn btn-default btn-control" type="button" >1회선 (요금6만5천원이상)</button>
									</div>
									<div class="col-md-6">
										<button class="mb-xs mt-xs mr-xs btn btn-default btn-control" type="button">2회선 (요금6만5천원이상)</button>
									</div>
								<?php
									}
								?>
								
							</div>
						</div>
					</section>
				</div>
			</div>
			<hr class="tall mt-xs mb-md">

			<div class="row">
				<div class="col-md-6">
					<ul class="list-unstyled mb-none t_list_txt">
						<li>
							월 예상 납부 금액
						</li>
					</ul>
				</div>
				<div class="col-md-6">
					<section class="panel panel-transparent mb-none">
						<div class="panel-body">
							<div class="alert alert-default">
								<strong>월 예상 납입금액 <span class="text-danger"><?php echo number_format($total_price);?></span>원</strong>
							</div>
						</div>
					</section>
				</div>
			</div>
			<hr class="tall mt-none mb-md">
			<div class="conbox">
				<ul class="list-unstyled mb-none t_list">
					<li>
						※ 간편요금계산은 월 납입 금액 결과는 6만5천원 이상 요금 일경우 할인되며 이동전화 요금및 할인은 제외한 금액입니다.
					</li>
					<li>
						※ TV 셋톱박스 최신장비 기준이며 기타 셋톱은 문의 및 다셋탑 TV 추가 설치는 별도 문의 하시면 상세히 안내 해드리겠습니다.
					</li>
				</ul>
			</div>

			<div class="row text-center">
				<button class="price_btn" type="submit">
				    온라인 가입 신청
				</button>
				<a class="price_btn" href="#" data-toggle="modal" data-target="#call_form">
				    무료 전화상담
				</a>
			</div>
			
		</div>
	</div>
</div>
</form>
